package com.flipkart.form;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.VoiceElementConfig;
import com.audium.server.xml.VoiceElementConfig.StaticAudio;

public class MainMenuDM implements VoiceElementInterface {

	@Override
	public VoiceElementConfig getConfig(String arg0, ElementAPI elementAPI,
			VoiceElementConfig defaults) throws AudiumException {
		
		try {
			 VoiceElementConfig.AudioGroup initialAudioGroup = defaults.new AudioGroup("initial_audio", true);
			 StaticAudio audio1 = defaults.new StaticAudio("401.wav");
			 initialAudioGroup.addAudioItem(audio1);
			 StaticAudio audio2 = defaults.new StaticAudio("402.wav");
			 initialAudioGroup.addAudioItem(audio2);
			 StaticAudio audio3 = defaults.new StaticAudio("403.wav");
			 initialAudioGroup.addAudioItem(audio3);
			 
			 defaults.setAudioGroup(initialAudioGroup);
			 
			 VoiceElementConfig.AudioGroup noInputAudioGroup = defaults.new AudioGroup("initial_audio", true);
			 StaticAudio noInput = defaults.new StaticAudio("101.wav");
			 initialAudioGroup.addAudioItem(noInput);
			 defaults.setAudioGroup(noInputAudioGroup);
			 
			 VoiceElementConfig.AudioGroup noInputAudioGroup2 = defaults.new AudioGroup("initial_audio", true);
			 StaticAudio noInput2 = defaults.new StaticAudio("101.wav");
			 initialAudioGroup.addAudioItem(noInput2);
			 defaults.setAudioGroup(noInputAudioGroup2);
			 
			 VoiceElementConfig.AudioGroup noMatchAudioGroup = defaults.new AudioGroup("initial_audio", true);
			 StaticAudio noMatch = defaults.new StaticAudio("102.wav");
			 initialAudioGroup.addAudioItem(noMatch);
			 defaults.setAudioGroup(noMatchAudioGroup);
			 
			 VoiceElementConfig.AudioGroup noMatchAudioGroup2 = defaults.new AudioGroup("initial_audio", true);
			 StaticAudio noMatch2 = defaults.new StaticAudio("102.wav");
			 initialAudioGroup.addAudioItem(noMatch2);
			 defaults.setAudioGroup(noMatchAudioGroup2);
			
			 String init_Audio =(String) elementAPI.getSessionData("Menu_audio");
			 String[] arr_init_Audio = init_Audio.split("\\|");
			 
			 StaticAudio init_a= null;
			 
			 for(String AudioInput : arr_init_Audio)
			 {
				 init_a = defaults.new StaticAudio(AudioInput);
				 initialAudioGroup.addAudioItem(init_a);
			 }
			 defaults.setAudioGroup(initialAudioGroup);
			 
			 
			 String KeyPressData =(String) elementAPI.getSessionData("KeyPress_value");
			 String KeyPressArray[] = KeyPressData.split("\\|");
			 
			 for (String dtmfInput : KeyPressArray)
			 {
				 defaults.addSettingValue("dtmf_keypress",dtmfInput);
			 }
			 
			 defaults.addSettingValue("input_mode","dtmf");
			 defaults.addSettingValue("noinput_count","3");
			 defaults.addSettingValue("nomatch_count","3");
			 defaults.addSettingValue("noinput_timeout","5s");
			 defaults.addSettingValue("dtmf_keypress","1");
			 defaults.addSettingValue("dtmf_keypress","2");
			 defaults.addSettingValue("dtmf_keypress","3");
			 defaults.addSettingValue("secure_logging"," true");	
			 
			 
		} catch (Exception e) {
			StringWriter log = new StringWriter();
			e.printStackTrace(new PrintWriter(log));
			elementAPI.addToLog("Exception :",log.toString());
		}
		
		return defaults;
	}

}
