package com.flipkart;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.audium.server.AudiumException;
import com.audium.server.global.ApplicationStartAPI;
import com.audium.server.proxy.StartApplicationInterface;

public class AppStart implements StartApplicationInterface {

	@Override
	public void onStartApplication(ApplicationStartAPI applicationStartAPI)
			throws AudiumException {
		try {
			String strConfigPath = "C:\\Servion\\Framework\\"; //config file path
			String strLog4j ="log4j.properties"; // log4g property file name
			String strIVRConfig = "IVRConfig.properties"; // ivr config property file name
			
			Properties PropLog4j = new Properties ();
			PropLog4j.load(new FileInputStream(new File(strConfigPath+strLog4j)));
			// concodinate file path with file name load the property file
			PropertyConfigurator.configure(PropLog4j);
			
			Logger log = Logger.getLogger("FLIPKART_CVF"); // get the logs from appliction 
			log.debug("Log4j loaded successfully");
			
			Properties PropIVRConfig = new Properties();
			PropIVRConfig.load(new FileInputStream(new File(strConfigPath+strIVRConfig)));
			applicationStartAPI.setApplicationData("IVR CONFIG",PropIVRConfig);
			log.info("IVRConfig loaded successfully");
			
			
		}catch(Exception e){
			
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		try {
			String strConfigPath = "C:\\Servion\\Framework\\FLIPKART_CVP\\";
			String strLog4j ="log4j.properties";
			String strIVRConfig = "IVRConfig.properties";
			
			Properties PropLog4j = new Properties ();
			PropLog4j.load(new FileInputStream(new File(strConfigPath+strLog4j)));
			PropertyConfigurator.configure(PropLog4j);
			
			Logger log = Logger.getLogger("Test_CVP");
			log.debug("Log4j loaded successfully");
			
			Properties PropIVRConfig = new Properties();
			PropIVRConfig.load(new FileInputStream(new File(strConfigPath+strIVRConfig)));
			log.info("IVRConfig loaded successfully");
			
		}catch(Exception e){
			
			e.printStackTrace();
		}
		
	
}
}

