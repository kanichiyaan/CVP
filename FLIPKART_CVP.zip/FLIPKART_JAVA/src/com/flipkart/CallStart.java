package com.flipkart;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.audium.server.AudiumException;
import com.audium.server.proxy.StartCallInterface;
import com.audium.server.session.CallStartAPI;

public class CallStart implements StartCallInterface {

	@Override
	public void onStartCall(CallStartAPI callStartAPI) throws AudiumException {
		// TODO Auto-generated method stub

		try {
			callStartAPI.addToLog("Call Start", "call entered into the application");
			Properties PropIVRConfig = (Properties) callStartAPI.getApplicationAPI().getApplicationData("IVRConfig");
			Properties PropGlobalIVRConfig = (Properties) callStartAPI.getApplicationAPI().getGlobalData("GLOBAL_IVRConfig");
			String noInputCount = PropIVRConfig.getProperty("NO_INPUT_COUNT");
			String noMatchCount = PropIVRConfig.getProperty("NO_MATCH_COUNT");
			String noInputTimeout = PropIVRConfig.getProperty("NO_INPUT_TIMEOUT");
			
			
			callStartAPI.setSessionData("NO_INPUT_COUNT", noInputCount);
			callStartAPI.setSessionData("NO_MATCH_COUNT", noMatchCount);
			callStartAPI.setSessionData("NO_INPUT_TIMEOUT", noInputTimeout);
			
		}catch(Exception e){
			StringWriter str = new StringWriter();
			e.printStackTrace(new PrintWriter(str));
			callStartAPI.addToLog("Exception :",str.toString());
		}
		
	
		
	}

}
