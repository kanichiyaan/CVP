package com.flipkart.audio;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.audium.core.voiceelement.VoiceElementDataInterface;
import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.VoiceElementConfig;
import com.audium.server.xml.VoiceElementConfig.StaticAudio;


public class AgentTransferAudio implements  VoiceElementInterface{

	@Override
	public VoiceElementConfig getConfig(String name, ElementAPI elementAPI,
			VoiceElementConfig defaults) throws AudiumException {
		
			
		try {
			
			VoiceElementConfig.AudioGroup initialAudioGroup = defaults.new AudioGroup("intial_audio",true);
			StaticAudio AgentTransfer = defaults.new StaticAudio("601.wav");
			initialAudioGroup.addAudioItem(AgentTransfer);
			defaults.setAudioGroup(initialAudioGroup);
			
			

		} catch (Exception e) {
			StringWriter s = new StringWriter();
			e.printStackTrace(new PrintWriter(s));
			elementAPI.addToLog("Exception :",s.toString());
		}
		return null;
	}

}
