package com.flipkart.audio;


import java.awt.JobAttributes.DefaultSelectionType;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.rules.ConstantStringCondition;
import com.audium.server.session.ElementAPI;
import com.audium.server.voiceElement.AudioGroup;
import com.audium.server.xml.VoiceElementConfig;
import com.audium.server.xml.VoiceElementConfig.StaticAudio;

public class MaxExceedAudio implements VoiceElementInterface {

	@Override
	public VoiceElementConfig getConfig(String name, ElementAPI elementAPI,
			VoiceElementConfig defaults) throws AudiumException {
			boolean bargein = true; 
		try {
			
		VoiceElementConfig.AudioGroup intialAudioGroup = defaults. new AudioGroup("initial_audio", true);
		StaticAudio  maxaudio = defaults.new StaticAudio("103.wav");
		intialAudioGroup.addAudioItem(maxaudio);
		defaults.setAudioGroup(intialAudioGroup);
			
		} catch (Exception e) {
		StringWriter s = new StringWriter();
		e.printStackTrace(new PrintWriter(s));
		elementAPI.addToLog("Exception :",s.toString());
		}
		return defaults;
	}

}

