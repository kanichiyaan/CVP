package com.flipkart.decision;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.audium.server.AudiumException;
import com.audium.server.session.DecisionElementData;
import com.audium.server.voiceElement.DecisionElementBase;


public class Menu_BC extends DecisionElementBase {

		@Override
		public String doDecision(String arg0, DecisionElementData data)
				throws AudiumException {
			String strExitState="ER";
			try {
				String strMenuInput = (String) data.getSessionData("MenuInput");
				if(strMenuInput != null && strMenuInput.equalsIgnoreCase("1"))
				{
					strExitState="option1";
				}
				else if(strMenuInput != null && strMenuInput.equalsIgnoreCase("2")) 
				{
					strExitState="option2";
				}
				else if(strMenuInput != null && strMenuInput.equalsIgnoreCase("3")) 
				{
					strExitState="option3";
				}
				
				
				
			} catch (Exception e) {
				StringWriter str = new StringWriter();
				e.printStackTrace(new PrintWriter(str));
				data.addToLog("Exception :",str.toString());

			}

			return null;
		}

	}


