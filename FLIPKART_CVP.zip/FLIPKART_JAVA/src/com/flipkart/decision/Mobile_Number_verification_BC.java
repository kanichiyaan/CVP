package com.flipkart.decision;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.audium.server.AudiumException;
import com.audium.server.session.DecisionElementData;
import com.audium.server.voiceElement.DecisionElementBase;

public class Mobile_Number_verification_BC extends DecisionElementBase {

			@Override
			public String doDecision(String arg0, DecisionElementData data)
					throws AudiumException {
				String strExitState="ER";
				try {
					String MoblieNo = (String) data.getSessionData("Mobile_No");
					String CustMobNo = (String) data.getSessionData("cus_mob_no");
					if(MoblieNo != null && MoblieNo.equals(CustMobNo)){
						strExitState="Verified";
					}else {
						strExitState="failure";
					}
					
					
					
				} catch (Exception e) {
					StringWriter str = new StringWriter();
					e.printStackTrace(new PrintWriter(str));
					data.addToLog("Exception :",str.toString());

				}

				return null;
			}

		}

